# Phase 00 - Project Overview

## 目標

建立 MemoryInspector 的完整產品邊界、名詞與開發順序。

## 產品模組

- Process Explorer
- Monitoring Session
- Memory Region Viewer
- Memory Scanner
- Duration Filter
- Filter Pipeline
- Branching Scan Tree
- Snapshot Storage
- Watch Window
- Saved Address
- Optional Memory Editor
- Temporary Manager
- Plugin Framework
- Module / Thread Viewer
- Hex Viewer
- Snapshot Compare

## 核心使用流程

```text
選擇 Process
→ 建立 Monitoring Session
→ 查看 Memory Regions
→ First Scan
→ 多輪 Filter
→ Keep / Undo / Branch
→ Watch / Save Address
```

## 非功能需求

- WPF UI 不凍結
- 支援大量 Candidate
- 支援取消
- 支援工作階段恢復
- 清楚錯誤訊息
- 可測試、可擴充
- x64 優先

## 驗收標準

- 所有 Phase 有清楚相依關係。
- README 說明開發順序。
- 專案命名統一使用 `MemoryInspector`。
