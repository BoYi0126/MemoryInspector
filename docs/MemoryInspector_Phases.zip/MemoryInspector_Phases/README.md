# MemoryInspector Phase Development Pack

## 專案定位

MemoryInspector 是一套以 **WPF + .NET 10 + MVVM** 建立的 Windows 記憶體分析平台。

此套文件已將整體專案拆成可逐步交付給 Agent 的多個 Phase，每個 Phase 都包含：

- 目標
- 相依階段
- 實作範圍
- 建議檔案結構
- 驗收標準
- 不在本階段處理的內容

## 建議執行方式

每次只交付一個 Phase 給 Agent。

建議 Prompt：

```text
請依照 Phase_XX_*.md 實作本階段。
開始前先閱讀：
- README.md
- Phase_00_ProjectOverview.md
- Phase_01_SolutionArchitecture.md
- 目前 Phase 文件

限制：
1. 不要提前實作後續 Phase。
2. 完成後執行 build 與 tests。
3. 更新 DevelopmentProgress.md 與 ModuleStatus.md。
4. 列出本次新增、修改檔案。
5. 說明尚未完成項目。
```

## Phase 清單

| Phase | 內容 |
|---|---|
| 00 | 專案總覽 |
| 01 | Solution 與架構 |
| 02 | 共用模型與 Result Pattern |
| 03 | 設定、日誌與儲存路徑 |
| 04 | Process Explorer Core |
| 05 | Process Explorer UI |
| 06 | Monitoring Session |
| 07 | Windows Memory Region Provider |
| 08 | Memory Region Viewer UI |
| 09 | Memory Reader Core |
| 10 | Scanner 基礎與數值解析 |
| 11 | First Scan - Exact Value |
| 12 | Unknown Initial Value |
| 13 | Next Scan 比對策略 |
| 14 | Duration Filter |
| 15 | Filter Pipeline |
| 16 | Scan History 與 Undo |
| 17 | Branching Scan Tree |
| 18 | Binary Snapshot Storage |
| 19 | Delta Snapshot 與 Reference Count |
| 20 | LRU Cache 與 Memory Budget |
| 21 | Result Grid Virtualization |
| 22 | Watch Window |
| 23 | Saved Address JSON |
| 24 | Memory Editor 模組骨架 |
| 25 | Temporary Manager |
| 26 | Plugin Framework |
| 27 | Module / Thread Viewer |
| 28 | Hex Viewer |
| 29 | Snapshot Compare |
| 30 | 整合測試與效能驗收 |
| 31 | Release、文件與封裝 |

## 重要架構原則

- UI 不直接呼叫 Windows Native API。
- Core 不依賴 WPF。
- Windows Adapter 封裝平台實作。
- 所有長時間工作支援 `CancellationToken`。
- 大量候選結果不得全部建立成 ViewModel。
- Scan Tree 節點不得全部常駐 RAM。
- 預設以唯讀分析為核心。
- Memory Editor 為獨立、明確啟用的模組。
- 不實作權限繞過、保護規避、注入、Hook 或核心驅動。
